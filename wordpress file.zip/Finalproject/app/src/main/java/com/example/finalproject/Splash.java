package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Timer timer = new Timer();
       final  User user =new User(Splash.this);
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                    if(user.getName()!="") {
                        Intent i = new Intent(Splash.this, Homepage.class);
                        i.putExtra("username", user.getName());
                        startActivity(i);
                    }
else{
                        Intent i = new Intent(Splash.this, MainActivity.class);

                        startActivity(i);

                    }
            }
        },2000);
    }


}
