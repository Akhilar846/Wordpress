package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayHouse extends AppCompatActivity {

    ImageView imgView;
    TextView t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_house);

        Intent i = getIntent();

      String price =  i.getStringExtra("price");
        String area = i.getStringExtra("area");
        String furnished = i.getStringExtra("furnish");
        int image =i.getIntExtra("image",0);


        imgView = findViewById(R.id.imageView);
        t1=findViewById(R.id.textView10);
        t2=findViewById(R.id.textView12);
        t3=findViewById(R.id.textView14);


        t1.setText(area);
        t2.setText(price);
        t3.setText(furnished);
        imgView.setImageResource(image);


    }
}
