package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    Button register,login;
    EditText textUsername,textPassword;
    DatabaseHelper db;
    CheckBox checkBox;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        register = findViewById(R.id.register);
        textPassword=findViewById(R.id.pass);
        textUsername=findViewById(R.id.name);
        login=findViewById(R.id.submit);
        //Toolbar toolbar = findViewById(R.id.actionbar);

        checkBox = findViewById(R.id.checkBox);
        db = new DatabaseHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Register.class);
                startActivity(i);

            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                textPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                textPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String user = textUsername.getText().toString().trim();
            String psd = textPassword.getText().toString().trim();
                User user_details = new User(MainActivity.this);
                user_details.setName(user);

            Boolean res = db.checkUser(user,psd);

            if(user.isEmpty()||psd.isEmpty()){
                Toast.makeText(MainActivity.this,"enter the fields", Toast.LENGTH_LONG).show();
            }else{
            if(res==true){
                Toast.makeText(MainActivity.this,"Successfully loggedin", Toast.LENGTH_LONG).show();

               if(user_details.getName()!="") {
                   Intent i = new Intent(getApplicationContext(), Homepage.class);
                   i.putExtra("username",user_details.getName());
                   startActivity(i);

               }else{

                   Intent i = new Intent(getApplicationContext(), MainActivity.class);

                   startActivity(i);

               }
            }
            else{
                Toast.makeText(MainActivity.this,"login error",Toast.LENGTH_LONG).show();
            }}
            }
        });

    }
}
