package com.example.finalproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Contact extends AppCompatActivity {

    EditText e1,e2,e3;
    Button b;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        e1 = findViewById(R.id.name);
        e2 = findViewById(R.id.pass);
        e3= findViewById(R.id.desc);
        b = findViewById(R.id.submit);

        t1 =findViewById(R.id.userwelcome);
        User u =new User(Contact.this);
       String name = u.getName();
        t1.setText("Hey"+ " "+ name + " " + "What`sup");
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(e1.getText().toString().isEmpty()||e2.getText().toString().isEmpty()||e3.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"enter all fields",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(),"We will get back to you shortly",Toast.LENGTH_LONG).show();
                }

            }
        });
    }
}
