package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Homepage extends AppCompatActivity {

    TextView txt;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        txt = findViewById(R.id.textView2);
        user  = new User(Homepage.this);
        Intent i = getIntent();
        String username = i.getStringExtra("username");
        txt.setText("Welcome" + " " + username);


    }

    public void logout(View view) {
        user.removeUser();
        Toast.makeText(getApplicationContext(),"Logged out",Toast.LENGTH_LONG).show();
        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
        finish();
    }

    public void contact(View view) {
        Toast.makeText(getApplicationContext(),"Contact Us",Toast.LENGTH_LONG).show();
        Intent i = new Intent(getApplicationContext(),Contact.class);
        startActivity(i);

    }

    public void aboutus(View view) {
        Toast.makeText(getApplicationContext(),"about Us",Toast.LENGTH_LONG).show();
        Intent i = new Intent(getApplicationContext(),Aboutus.class);
        startActivity(i);

    }

    public void productlist(View view) {
        Toast.makeText(getApplicationContext(),"product list",Toast.LENGTH_LONG).show();
        Intent i = new Intent(getApplicationContext(),Display.class);
        startActivity(i);

    }
}
