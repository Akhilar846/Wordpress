package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    Button register;
    CheckBox checkBox;
    EditText textUsername,textPassword1,textConformPassword;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        textConformPassword = findViewById(R.id.conformpass2);
        textPassword1=findViewById(R.id.pass2);
        textUsername=findViewById(R.id.name);
        register=findViewById(R.id.submit);
        db = new DatabaseHelper(this);
        checkBox = findViewById(R.id.checkBox2);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    textPassword1.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    textConformPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    textPassword1.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    textConformPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = textUsername.getText().toString().trim();
                String password = textPassword1.getText().toString().trim();
                String conform_password=textConformPassword.getText().toString().trim();
                if(user.isEmpty()||password.isEmpty()||conform_password.isEmpty()) {
                    Toast.makeText(Register.this,"enter the required fields",Toast.LENGTH_LONG).show();
                }else{
                if(password.equals(conform_password)){
                  long val =  db.addUser(user,password);
if(val>0) {
    Toast.makeText(Register.this,"You have registered",Toast.LENGTH_LONG).show();
    Intent intent = new Intent(Register.this, MainActivity.class);
    startActivity(intent);
}
if(val==-2){
    Toast.makeText(Register.this,"user already exists",Toast.LENGTH_LONG).show();
}
else {

    Toast.makeText(Register.this," registration failed",Toast.LENGTH_LONG).show();
}
                }else{
                    Toast.makeText(Register.this,"Password do not match registration failed",Toast.LENGTH_LONG).show();
                }}
            }
        });
    }
}
