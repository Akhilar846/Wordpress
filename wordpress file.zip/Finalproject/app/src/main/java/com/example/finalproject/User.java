package com.example.finalproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class User {
    Context context;
    private String name;
    SharedPreferences sp;

    public User(Context context){
        this.context=context;
        /*sp = PreferenceManager.getSharedPreferences(this.context);
        SharedPreferences.Editor editor = sp.edit();*/

    //sp = context.getSharedPreferences("userinfo", Context.MODE_PRIVATE);

sp = PreferenceManager.getDefaultSharedPreferences(this.context);
    }
    public void removeUser(){
        sp.edit().clear().commit();
    }

    public String getName() {
      name =  sp.getString("userdata","");
        return name;
    }

    public void setName(String name) {
        this.name = name;
        sp.edit().putString("userdata",name).commit();
    }
}
