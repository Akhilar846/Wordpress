package com.example.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Display extends AppCompatActivity {

    GridView g;

    int[] img = {R.drawable.house1,R.drawable.house2,R.drawable.house3,R.drawable.house8,R.drawable.house5,R.drawable.house7};
    String[] price = {"$99999","$99999","$99999","$99999","$99999","$99999"};
    String[] area = {"Kitchener","Waterloo","Kitchener","Waterloo","Kitchener","Cambridge"};
    String[] furnish = {"yes","no","yes","no","yes","yes"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        g = (GridView)findViewById(R.id.grid);

        Customadapter ab = new Customadapter();

        g.setAdapter(ab);
        g.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String name = area[position];
                Toast.makeText(Display.this,name,Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Display.this,DisplayHouse.class);
                i.putExtra("area",area[position]);
                i.putExtra("price",price[position]);
                i.putExtra("furnish",furnish[position]);
                i.putExtra("image",img[position]);
                startActivity(i);

            }
        });

    }

    class Customadapter extends BaseAdapter {

        @Override
        public int getCount() {
            return price.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = getLayoutInflater().inflate(R.layout.grid,null);
            ImageView im = (ImageView)convertView.findViewById(R.id.img);
            TextView tx = (TextView)convertView.findViewById(R.id.text);

            im.setImageResource(img[position]);
            tx.setText(price[position]);

            return convertView;
        }
    }
}